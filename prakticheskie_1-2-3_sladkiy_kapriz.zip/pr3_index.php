<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Кондитерская «Сладкий каприз»</title>
<style>
  body { font-family: Tahoma, sans-serif; background:#FFF8F0; color:#5A3E36; margin:0; }
  header { background:#F4C2C2; padding:30px; text-align:center; }
  main { display:flex; justify-content:space-between; padding:30px; flex-wrap:wrap; }
  .about, .auth { background:#fff; border-radius:10px; padding:20px; width:45%; box-shadow:0 0 8px #ddd; }
  footer { background:#5A3E36; color:#fff; text-align:center; padding:15px; }
</style>
</head>
<body>
<header>
  <h1>Кондитерская «Сладкий каприз»</h1>
  <p>Выпечка тортов на заказ с 2015 года</p>
</header>
<main>
  <section class="about">
    <h2>О нас</h2>
    <p>Авторские торты на заказ: свадебные, детские, корпоративные.</p>
  </section>
  <section class="auth">
    <h2>Авторизация</h2>
    <form action="#" method="post">
      <label>Логин: <input type="text" name="username"></label><br>
      <label>Пароль: <input type="password" name="password"></label><br>
      <button type="submit">Войти</button>
    </form>
  </section>
</main>
<footer>
  <p>Телефон: +7 (900) 123-45-67 | Email: sweet.caprice@example.com</p>
</footer>
</body>
</html>
