<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Пирамида</title>
</head>
<body>
<h1>Пирамида из цифр</h1>
<pre>
<?php
// Строка i состоит из цифры i, повторённой i раз (i = 2..9)
for ($i = 2; $i <= 9; $i++) {
    for ($j = 1; $j <= $i; $j++) {
        echo $i;
    }
    echo "\n";
}
?>
</pre>
</body>
</html>
