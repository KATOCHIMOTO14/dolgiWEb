<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Библиотека: выдача учебников</title>
    <style type="text/css">
        table { border-collapse: collapse; }
        td, th { width: 200px; border: 1px solid black; padding: 4px; }
    </style>
</head>
<body>
<h1>Выдача учебников студентам</h1>
<?php
const LIMIT = 10;   // библиотека не выдаёт больше 10 учебников
const EXTRA = 5;    // преподаватель попросил взять ещё 5

// Ассоциативный массив: ФИО => количество выданных учебников
$books = array(
    'Ларьков А.Л.'     => 6,
    'Павлов А.Д.'      => 0,
    'Алксандров А.Ж.'  => 4,
    'Иванова И.П.'     => 3,
    'Марков П.Н.'      => 9
);

// Новый массив: к каждому добавляем 5, но не больше LIMIT
$books_today = array();
foreach ($books as $name => $count) {
    $books_today[$name] = min($count + EXTRA, LIMIT);
}

// Вывод таблицы
$table = '';
$j = 0;
foreach ($books as $name => $old) {
    $j++;
    $new = $books_today[$name];
    $table .= "<tr>
        <td>{$j}</td>
        <td>{$name}</td>
        <td>{$old}</td>
        <td>{$new}</td>
    </tr>";
}
?>
<table>
    <tr>
        <th>№ п/п</th>
        <th>ФИО студента</th>
        <th>До сегодняшнего дня</th>
        <th>В конце сегодняшнего дня</th>
    </tr>
    <?php echo $table; ?>
</table>
<p>Всего учебников: до — <?php echo array_sum($books); ?>,
   после — <?php echo array_sum($books_today); ?></p>
</body>
</html>
