-- База данных кондитерской по выпечке тортов на заказ
CREATE DATABASE IF NOT EXISTS confectionery
    CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE confectionery;

-- 1. Пользователи (данные формы регистрации + служебные поля)
CREATE TABLE user (
    id            INT           NOT NULL AUTO_INCREMENT,
    first_name    CHAR(30)      NOT NULL,
    last_name     CHAR(30)      NOT NULL,
    user_name     CHAR(20)      NOT NULL UNIQUE,
    password      VARCHAR(255)  NOT NULL,           -- хеш от password_hash()
    email         CHAR(50)      NOT NULL,
    vk_url        CHAR(50)      NULL,
    user_pic_path CHAR(100)     NULL,
    biography     VARCHAR(400)  NULL,
    date_reg      INT           NOT NULL,           -- время регистрации (time())
    check_email   TINYINT(1)    NOT NULL DEFAULT 0, -- почта подтверждена
    administrator TINYINT(1)    NOT NULL DEFAULT 0, -- администратор (логическое)
    token         CHAR(30)      NULL,               -- для cookie-авторизации
    PRIMARY KEY (id)
) ENGINE=InnoDB;

-- 2. Торты (каталог)
CREATE TABLE cake (
    id_cake     INT           NOT NULL AUTO_INCREMENT,
    name        CHAR(50)      NOT NULL,
    description VARCHAR(400)  NOT NULL,
    price       DECIMAL(8,2)  NOT NULL,
    weight_kg   DECIMAL(4,2)  NOT NULL,
    photo_path  CHAR(100)     NULL,
    PRIMARY KEY (id_cake)
) ENGINE=InnoDB;

-- 3. Заказы (связь «один-ко-многим»: один пользователь — много заказов)
CREATE TABLE orders (
    id_order    INT           NOT NULL AUTO_INCREMENT,
    id_user     INT           NOT NULL,
    date_order  INT           NOT NULL,             -- когда оформлен
    date_ready  DATE          NOT NULL,             -- на какую дату нужен торт
    address     VARCHAR(200)  NULL,                 -- доставка (необязательно)
    status      ENUM('new','baking','ready','done','canceled') NOT NULL DEFAULT 'new',
    comment     VARCHAR(400)  NULL,                 -- надпись на торте, пожелания
    PRIMARY KEY (id_order),
    CONSTRAINT orders_ibfk_1 FOREIGN KEY (id_user) REFERENCES user (id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 4. Состав заказа — промежуточная таблица для связи «многие-ко-многим»
--    (в одном заказе несколько тортов, один торт — в разных заказах)
CREATE TABLE order_item (
    id_order    INT           NOT NULL,
    id_cake     INT           NOT NULL,
    quantity    INT           NOT NULL DEFAULT 1,
    PRIMARY KEY (id_order, id_cake),
    CONSTRAINT order_item_ibfk_1 FOREIGN KEY (id_order) REFERENCES orders (id_order)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT order_item_ibfk_2 FOREIGN KEY (id_cake) REFERENCES cake (id_cake)
        ON DELETE RESTRICT ON UPDATE CASCADE        -- торт из заказанных не удалить
) ENGINE=InnoDB;

-- Тестовые данные (для проверки связей)
INSERT INTO user (first_name, last_name, user_name, password, email, date_reg, administrator)
VALUES ('Анна', 'Петрова', 'anna_p', 'hash_stub', 'anna@example.com', UNIX_TIMESTAMP(), 0),
       ('Админ', 'Админов', 'admin1', 'hash_stub', 'admin@example.com', UNIX_TIMESTAMP(), 1);

INSERT INTO cake (name, description, price, weight_kg) VALUES
       ('Наполеон',    'Слоёный торт с заварным кремом', 1800.00, 1.50),
       ('Красный бархат', 'Бисквит с сырным кремом',       2400.00, 2.00),
       ('Медовик',     'Медовые коржи со сметанным кремом', 1600.00, 1.80);

INSERT INTO orders (id_user, date_order, date_ready, status, comment)
VALUES (1, UNIX_TIMESTAMP(), CURDATE() + INTERVAL 3 DAY, 'new', 'Надпись: С днём рождения!');

INSERT INTO order_item (id_order, id_cake, quantity) VALUES (1, 1, 1), (1, 3, 2);

-- Проверка каскада: удаление пользователя удалит его заказы и состав заказов
-- DELETE FROM user WHERE id = 1;
